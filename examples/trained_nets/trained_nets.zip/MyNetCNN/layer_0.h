#ifndef _LAYER_layer_0_H_
#define _LAYER_layer_0_H_


#include <NetworkConfig.h>


#define layer_0_type "convolution"

sLayerGeometry layer_0_input_geometry = {28, 28, 1};
sLayerGeometry layer_0_output_geometry = {28, 28, 8};
sLayerGeometry layer_0_kernel_geometry = {3, 3, 8};

#define layer_0_weights_size ((unsigned int)72) //array size
#define layer_0_weights_range ((nn_t)537) //multiply neuron result with range/1024

const nn_weight_t layer_0_weights[]={
-24, 30, 55, -21, 46, 57, -30, 6, -29, -74, -21, 9, -76, 12, 9, -107, 
-46, -8, -23, -23, 11, -43, -5, -30, 49, 29, 5, -7, -83, -15, 29, 44, 
26, 14, 18, -31, 90, 70, 127, 54, 82, 80, -55, -45, 14, -50, -37, -31, 
28, 23, 0, 43, -6, 14, -80, -52, 50, -40, 12, 45, -54, 27, 16, 32, 
-36, -77, 79, 10, -34, 48, 22, 62, };




#define layer_0_bias_size ((unsigned int)8) //array size
#define layer_0_bias_range ((nn_t)264) //multiply neuron result with range/1024

const nn_weight_t layer_0_bias[]={
-1, 127, -17, -2, 0, -25, -3, 0, };


#endif
