#ifndef _LAYER_layer_4_H_
#define _LAYER_layer_4_H_


#include <NetworkConfig.h>


#define layer_4_type "relu"

sLayerGeometry layer_4_input_geometry = {14, 14, 16};
sLayerGeometry layer_4_output_geometry = {14, 14, 16};
sLayerGeometry layer_4_kernel_geometry = {14, 14, 16};





#endif
