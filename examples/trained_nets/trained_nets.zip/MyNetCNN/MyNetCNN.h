#ifndef _NETWORK_MyNetCNN_H_
#define _NETWORK_MyNetCNN_H_

#include <NeuralNetwork.h>

class MyNetCNN: public NeuralNetwork
{
	public:
		MyNetCNN();
		virtual ~MyNetCNN();
};

#endif
