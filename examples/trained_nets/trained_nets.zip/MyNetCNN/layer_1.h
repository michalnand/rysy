#ifndef _LAYER_layer_1_H_
#define _LAYER_layer_1_H_


#include <NetworkConfig.h>


#define layer_1_type "relu"

sLayerGeometry layer_1_input_geometry = {28, 28, 8};
sLayerGeometry layer_1_output_geometry = {28, 28, 8};
sLayerGeometry layer_1_kernel_geometry = {28, 28, 8};





#endif
