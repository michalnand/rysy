#ifndef _NETWORK_MyNetDCNN_H_
#define _NETWORK_MyNetDCNN_H_

#include <NeuralNetwork.h>

class MyNetDCNN: public NeuralNetwork
{
	public:
		MyNetDCNN();
		virtual ~MyNetDCNN();
};

#endif
