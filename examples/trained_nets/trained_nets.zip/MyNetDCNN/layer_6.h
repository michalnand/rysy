#ifndef _LAYER_layer_6_H_
#define _LAYER_layer_6_H_


#include <NetworkConfig.h>


#define layer_6_type "relu"

sLayerGeometry layer_6_input_geometry = {14, 14, 24};
sLayerGeometry layer_6_output_geometry = {14, 14, 24};
sLayerGeometry layer_6_kernel_geometry = {14, 14, 24};





#endif
