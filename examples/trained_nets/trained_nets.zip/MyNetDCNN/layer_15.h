#ifndef _LAYER_layer_15_H_
#define _LAYER_layer_15_H_


#include <NetworkConfig.h>


#define layer_15_type "relu"

sLayerGeometry layer_15_input_geometry = {7, 7, 56};
sLayerGeometry layer_15_output_geometry = {7, 7, 56};
sLayerGeometry layer_15_kernel_geometry = {7, 7, 56};





#endif
