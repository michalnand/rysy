#ifndef _LAYER_layer_13_H_
#define _LAYER_layer_13_H_


#include <NetworkConfig.h>


#define layer_13_type "relu"

sLayerGeometry layer_13_input_geometry = {7, 7, 48};
sLayerGeometry layer_13_output_geometry = {7, 7, 48};
sLayerGeometry layer_13_kernel_geometry = {7, 7, 48};





#endif
